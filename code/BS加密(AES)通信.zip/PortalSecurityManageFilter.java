package com.feinno.framework.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.feinno.common.SysConstant;
import com.feinno.common.utils.CryptoUtil;
import com.feinno.framework.common.Constants;
import com.feinno.framework.common.enums.EnumSysUserType;
import com.feinno.framework.exception.PortalManageException;
import com.feinno.system.domain.Organization;
import com.feinno.system.domain.Resource;
import com.feinno.system.domain.Role;
import com.feinno.system.domain.User;
import com.feinno.system.manager.OrgManager;
import com.feinno.system.manager.ResourceManager;
import com.feinno.system.manager.UserManager;
@Service("portalSecurityManageFilter")
public class PortalSecurityManageFilter implements Filter {
    private final static Logger log = Logger.getLogger(PortalSecurityManageFilter.class);
    //按钮资源
    private final String RESTYPE="1";
   
    @Autowired
    private UserManager userManager;
    
    @Autowired
    private ResourceManager resourceManager;    

    @Autowired
    private OrgManager orgManager;
    
    private final List<String> excludes = new ArrayList<String>();
    
    @Override    
    public void init(FilterConfig filterConfig) throws ServletException {
        
        
        
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException,
        ServletException {
        User user = null;
        //String errCode = null;
        String errMsg = null;
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        HttpSession session = request.getSession();
        String url = request.getRequestURI();
        String contextPath = request.getContextPath();
        if (excludes.size()==0) {
            excludes.add(contextPath+"/portal/manage/knowledge/view.htm");
            excludes.add(contextPath+"/portal/manage/knowledge/downMulFile.htm");
            excludes.add(contextPath+"/portal/manage/knowledge/downFile.htm");
            excludes.add(contextPath + "/portal/manage/knowledge/queryKnowledges.htm");
            excludes.add(contextPath + "/portal/manage/knowledge/asynViewKnowledge.htm");
            excludes.add(contextPath + "/portal/manage/knowledge/downloadAttachment.htm");
            excludes.add(contextPath + "/portal/manage/knowledge/downloadAllAttachments.htm");
            excludes.add(contextPath+"/portal/manage/announce/view.htm");        
            excludes.add(contextPath+"/portal/manage/announce/downFile.htm");
            excludes.add(contextPath + "/portal/manage/announce/queryAnnounces.htm");
            excludes.add(contextPath + "/portal/manage/announce/asynViewAnnounce.htm");
            excludes.add(contextPath + "/portal/manage/announce/downloadAttachment.htm");
            excludes.add(contextPath+"/portal/manage/user/logout.htm");
            excludes.add(contextPath+"/portal/manage/knowledge/querylist.htm");
            excludes.add(contextPath+"/portal/manage/user/editPassword.htm");            
            excludes.add(contextPath+"/portal/manage/user/savePassword.htm");   
            excludes.add(contextPath+"/portal/manage/user/trustTurn.htm");
            excludes.add(contextPath+"/portal/manage/knowledge/existsFile.htm"); 
        }
        if (!url.startsWith(contextPath + SysConstant.PORTAL_URL_PREFIX) || excludes.contains(url)) {
            chain.doFilter(request, response);
            return;
        }
        // Object isSession =
        // session.getAttribute(SysConstant.PORTAL_USER_SESSION);
        // 判断是否需要进行登录处理
        // if (this.requiresAuthentication(request) && isSession==null) {
        if (this.requiresAuthentication(request)) {    
            String ip = request.getRemoteHost();
            String urlPath = request.getServletPath() == null ? "" : request.getServletPath();
            log.debug(String.format("用户：[%s] ，访问地址：[%s]", ip, urlPath));        
            // 用户名称
            String loginName = request.getParameter("j_username");
            if (loginName == null) {
                loginName = "";
            }        
            loginName = loginName.trim();
            // 校验码
            String validateCode = request.getParameter("j_validate");
            if (validateCode == null) {
                validateCode = "";
            } 
            request.setAttribute("loginName", loginName);
            validateCode = validateCode.trim();
            // 判断该用户名是否重复登录了5次，如果是，就把该用户名给锁住，不允许在登录了。
            Map<String, Integer> loginNumMap = (Map<String, Integer>) session.getAttribute(SysConstant.PORTAL_LOGIN_NUM);
            int valueNum = loginNumMap == null || loginNumMap.get(loginName) == null ? 0 : loginNumMap.get(loginName);
            if (valueNum > 4) {
                errMsg = "登录次数超过限制！";
                log.debug(String.format("用户：[%s] 认证出现异常。原因：[%s]", loginName, errMsg));
                request.setAttribute("errMsg", errMsg);
                request.getRequestDispatcher(SysConstant.PORTAL_MANAGE_PATH).forward(request, resp);               
                return;
            }            
            clearAncientSession(session);
            log.debug(String.format("用户：[%s] 登录认证进行中。", loginName));
            // 用户存在判断
            user = userManager.getUserByUsername(loginName,"1");            
            if (user!=null && 20000!=user.getOrganization().getId().longValue()) {
                user= null;                
            }            
            try {
                String j_password = request.getParameter("j_password");
                if (StringUtils.isEmpty(loginName) && StringUtils.isEmpty(j_password) && StringUtils.isEmpty(validateCode)) {
                    response.sendRedirect(request.getContextPath()+"/portalmanage.jsp");
                    return;   
                }
                if (user == null) {     
                    errMsg = "用户名或密码错误！";
                    log.debug(String.format("用户：[%s] 认证出现异常。原因：[%s]", loginName, errMsg));
                    request.setAttribute("errMsg", errMsg);
                    request.getRequestDispatcher(SysConstant.PORTAL_MANAGE_PATH).forward(request, response);                 
                    addLoginNum(loginName, session, "add");
                    return;
                } else {
                    user.setLoginip(request.getRemoteAddr()); // 记录登录IP
                    user.setLogindate(new Date());
                    userManager.update(user);
                    if (!validateCode.equals(session.getAttribute(SysConstant.PORTAL_VERIFY_CODE))) {
                        errMsg = "验证码错误！";
                        log.debug(String.format("用户：[%s] 认证出现异常。原因：[%s]", loginName, errMsg));
                        request.setAttribute("errMsg", errMsg);
                        request.getRequestDispatcher(SysConstant.PORTAL_MANAGE_PATH).forward(request, response);
                        addLoginNum(loginName, session, "add");                        
                        return;
                    }
                    // 尝试认证
                    this.attemptAuthentication(request, response);
                    session.setAttribute(SysConstant.PORTAL_USER_MANAGE_SESSION, user);
                    // 权限获取
                    this.authorizeResource(request);
                    // 登录成功，用户权限查询
                    log.debug(String.format("Congratulation! 用户：[%s] 认证成功。", loginName));
                    addLoginNum(loginName, session, "remove");                                        
                }
            } catch (PortalManageException e) {
                errMsg = e.getMessage();
            } catch (Exception failed) {
                errMsg = "未知错误，请联系管理员";
            }
            if (errMsg != null) {
                log.debug(String.format("用户：[%s] 认证出现异常。原因：[%s]", loginName, errMsg));
                request.setAttribute("errMsg", errMsg);
                request.getRequestDispatcher(SysConstant.PORTAL_MANAGE_PATH).forward(request, response);
                addLoginNum(loginName, session, "add");             
                return;
            }
        }
        
        //如果Session过期或没有登录，跳转到登录页面
        if (null == request.getSession().getAttribute(SysConstant.PORTAL_USER_MANAGE_SESSION))
        {
            String xreq = request.getHeader("X-Requested-With");
            if(xreq != null && "XMLHttpRequest".equalsIgnoreCase(xreq)){
                //TODO ajax 请求超时 前台做个 监听
                response.setHeader("sessionstatus", "portalManageTimeOut");
                //response.setHeader("loginUrl", request.getContextPath() +  failureMappings.getProperty(BaseConstants.SESSTIONTIMEEXCETION));
                return;
            } else { 
                errMsg = "用户会话超时！";
                log.debug(String.format("认证出现异常。原因：[%s]", errMsg));
                request.setAttribute("errMsg", errMsg);
                request.setAttribute("timeout", "1");
                request.getRequestDispatcher(SysConstant.PORTAL_MANAGE_PATH).forward(request, response);
                return; 
            }
        }
        
        chain.doFilter(request, response);
        return;
    }

    /**
     * 用户登录认证.
     * 
     * @param request
     * @param response
     * @return
     * @throws PortalManageException
     */
    protected void attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws PortalManageException {
        if (!(request.getMethod().equals("POST"))) {
            // 登录认证提交错误!
            // throw new PortalManageException("005");
            throw new PortalManageException("登录认证提交错误! ");
        }

        String loginName = request.getParameter("j_username");
        String password = request.getParameter("j_password");
        if (loginName == null) {
            loginName = "";
        }
        if (password == null) {
            password = "";
        }

        loginName = loginName.trim();
        // 解密 KEY
        String key = "50a9ea50333c8bf6";
        String encrypt_password = null;
        // 解密密码
        try {
            byte[] bytesPassword = Base64.decodeBase64(password);
            if (null != bytesPassword) {
                byte[] bytesTemp = CryptoUtil.decryptByAES(bytesPassword, key.getBytes(CryptoUtil.DEFAULT_CHARSET),
                        key.getBytes(CryptoUtil.DEFAULT_CHARSET));

                String decipher = "";
                if (null != bytesTemp) {
                    decipher = new String(bytesTemp, CryptoUtil.DEFAULT_CHARSET);
                }

                encrypt_password = CryptoUtil.enTDEA(Constants.SECRET_KEY_A, Constants.SECRET_KEY_B, decipher.trim());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 获取当前用户
        User user = userManager.getUserByUsername(loginName, "1");
        if (!user.getPassWord().equals(encrypt_password)) {
            // 用户帐户名或密码问题，请重新输入!
            // throw new PortalManageException("006","");
            throw new PortalManageException("用户名或密码错误!");
        } else if (user.getStatus() == 0) {
            // 0:停用 1：启用
            // 用户帐户已经被停用！
            // throw new PortalManageException("007","");
            throw new PortalManageException("用户帐户已经被停用！");
        }
    }
    
    /**
     * 根据用户得到该用户下的权限.
     * @param user
     */
    protected void authorizeResource(HttpServletRequest request) 
         throws PortalManageException {
        List<com.feinno.system.domain.Resource> resources = null;
        HttpSession session = request.getSession();
        Object obj = session.getAttribute(SysConstant.PORTAL_USER_MANAGE_SESSION);
        if (obj == null) {
            //访问权限不足，请重新登录!
            //throw new PortalManageException("008","");
            throw new PortalManageException("访问权限不足，请重新登录!");
        }
        List<String> ids = new ArrayList<String>();
        //获取当前用户
        User user = (User)obj;
        String userType = user.getType().toString();
        //获取当前用户可访问的资源  超级管理员
        if (EnumSysUserType.SUPER_ADMIN.getValue().equals(userType)) {
            //超级管理员获取所有的资源
            resources=resourceManager.getAllOrderCode(SysConstant.PORTAL_RESOURCE_PARENTID);
        } else if (EnumSysUserType.ORG_ADMIN.getValue().equals(userType)) {
            //机构管理员获取所有的资源
            Long id = user.getOrganization().getId();
            Organization org = orgManager.get(id);
            Set<com.feinno.system.domain.Resource> res = org.getRes();
            resources = new ArrayList<com.feinno.system.domain.Resource>(res);
        } else {
            Long id = user.getOrganization().getId();
            Organization org = orgManager.get(id);
            Set<com.feinno.system.domain.Resource> res = org.getRes();
            resources = new ArrayList<com.feinno.system.domain.Resource>(res);
            Map<Long, com.feinno.system.domain.Resource> map = new HashMap<Long, com.feinno.system.domain.Resource>();
            for (com.feinno.system.domain.Resource rr : res) {
                map.put(rr.getId(), rr);
            }
            
            //角色资源
            Map<Long, com.feinno.system.domain.Resource> resMap = new HashMap<Long, com.feinno.system.domain.Resource>();
            resources = new ArrayList<com.feinno.system.domain.Resource>();
            Set<Role> roles = user.getRoles();
            if (roles != null && roles.size() > 0) {
                for (Role role : roles) {
                    Set<com.feinno.system.domain.Resource> roleRes = role.getRes();
                    for (com.feinno.system.domain.Resource rr : roleRes) {
                        com.feinno.system.domain.Resource mapItem = map.get(rr.getId());
                        if (mapItem != null) {
                            resMap.put(rr.getId(), rr);
                        }
                    }
                }
            }
            //个人资源
            Set<com.feinno.system.domain.Resource> specs = user.getRes();
            if (specs != null && specs.size() > 0) {
                for (com.feinno.system.domain.Resource sprr : specs) {
                    com.feinno.system.domain.Resource mapItem = map.get(sprr.getId());
                    if (mapItem != null) {
                        com.feinno.system.domain.Resource resItem = resMap.get(sprr.getId());
                        if (resItem == null) {
                            resMap.put(sprr.getId(), sprr);
                        }
                    }
                }
            }
                       
            for (Resource r : resMap.values()) {
                    resources.add(r);
            }
        }
        
        // 按钮权限
        if (resources != null) {
            for (com.feinno.system.domain.Resource r : resources) {
               if (RESTYPE.equals(r.getResType())) { 
                ids.add(r.getId().toString());
               }
            }               
        }
        
        if (resources == null || resources.size() == 0) {
              throw new PortalManageException("权限不足，请联系管理员！");
         }
        
        //用户菜单权限
        session.setAttribute(SysConstant.PORTAL_RESOURCE_SESSION,resources);
        //用户按钮权限
        session.setAttribute(SysConstant.PORTAL_BUTTON_SESSION, ids);        
    }

    /**
     * 登录htm过滤判断.
     * @param request
     * @param response
     * @return
     */
    protected boolean requiresAuthentication(HttpServletRequest request) {
        String uri = request.getRequestURI();
        int pathParamIndex = uri.indexOf(';');
        if (pathParamIndex > 0) {
            uri = uri.substring(0, pathParamIndex);
        }
        if ("".equals(request.getContextPath())) {
            return uri.endsWith(SysConstant.PORTAL_LOGIN_HTM);
        }
        return uri.endsWith(request.getContextPath() + SysConstant.PORTAL_LOGIN_HTM);
    }

    /**
     * 移除session旧的数据.
     * @param request
     */
    protected void clearAncientSession(HttpSession session) {        
        session.removeAttribute(SysConstant.PORTAL_USER_MANAGE_SESSION);
        session.removeAttribute(SysConstant.PORTAL_RESOURCE_SESSION);
        session.removeAttribute(SysConstant.PORTAL_LOGIN_NUM);
     }

    /**
     * 记录同一个用户名登录的次数，超过5次就不让它在登录了。
     * @param loginName
     * @param session
     * @param addOrRemove
     */
    protected void addLoginNum(String loginName, HttpSession session, String addOrRemove) {
        Map<String, Integer> loginNumMap = (Map<String, Integer>) session.getAttribute(SysConstant.PORTAL_LOGIN_NUM);
        if ("add".equals(addOrRemove)) {
            if (loginNumMap == null) {
                loginNumMap = new HashMap<String, Integer>();
            }
            Integer value = loginNumMap.get(loginName);
            loginNumMap.put(loginName, value == null || value == 0 ? 1 : value + 1);
        }
        if ("remove".equals(addOrRemove)) {
            if (loginNumMap != null) {
                loginNumMap.remove(loginName);
            }
        }
        session.setAttribute(SysConstant.PORTAL_LOGIN_NUM, loginNumMap);
    }

    @Override
    public void destroy() {
        // TODO Auto-generated method stub

    }

}
