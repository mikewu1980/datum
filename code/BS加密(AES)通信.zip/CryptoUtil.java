package com.feinno.common.utils;

import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;

/**
 * @author ke.zhang 加密工具类
 */
public class CryptoUtil {
    private final static Logger log = Logger.getLogger(CryptoUtil.class);
    public static final String DEFAULT_CHARSET = "UTF-8";

    public static byte[] encryptMode(byte[] keyByte, byte[] src, String transformation) throws CryptoException {
        try {
            SecretKey deskey = new SecretKeySpec(keyByte, getAlgorithm(transformation));
            Cipher c1 = Cipher.getInstance(transformation);
            c1.init(Cipher.ENCRYPT_MODE, deskey);
            return c1.doFinal(src);
        } catch (java.security.NoSuchAlgorithmException nsae) {
            throw new CryptoException("算法错误", nsae);
        } catch (javax.crypto.NoSuchPaddingException nspe) {
            throw new CryptoException("填充格式错误", nspe);
        } catch (java.lang.Exception e) {
            throw new CryptoException(e);
        }
    }

    public static byte[] decryptMode(byte[] keyByte, byte[] src, String transformation) throws CryptoException {
        try {

            SecretKey deskey = new SecretKeySpec(keyByte, getAlgorithm(transformation));
            Cipher c1 = Cipher.getInstance(transformation);
            c1.init(Cipher.DECRYPT_MODE, deskey);
            return c1.doFinal(src);
        } catch (java.security.NoSuchAlgorithmException nsae) {
            nsae.printStackTrace();
            throw new CryptoException("算法错误");
        } catch (javax.crypto.NoSuchPaddingException nspe) {
            nspe.printStackTrace();
            throw new CryptoException("填充格式错误");
        } catch (java.lang.Exception e) {
            e.printStackTrace();
            throw new CryptoException();
        }
    }

    /**
     * @param kap
     *            密钥，进行的第一次加密和第三次加密
     * @param kbp
     *            密钥，进行第二次解密
     * @param src
     *            待加密数据
     * @return 加密数据
     * @throws CryptoException
     */
    public static byte[] encryptTripleDES(byte[] kap, byte[] kbp, byte[] src) throws CryptoException {
        if (kap == null || kap.length != 8 || kbp == null || kbp.length != 8) {
            throw new CryptoException("密钥长度错误");
        }
        src = olsysDesPadding(src);
        byte[] keyBytes = ByteUtil.contactArray(kap, kbp);
        keyBytes = ByteUtil.contactArray(keyBytes, kap);
        return encryptTripleDES(keyBytes, src, "ECB", "NoPadding");
    }

    public static byte[] encryptTripleDES(byte[] keyBytes, byte[] src, String mode, String padding)
            throws CryptoException {
        String transformation = "DESede" + "/" + mode + "/" + padding;
        return encryptMode(keyBytes, src, transformation);
    }

    /**
     * @param kap
     *            密钥，进行的第一次解密和第三次解密
     * @param kbp
     *            密钥，进行第二次加密
     * @param src
     *            加密数据
     * @return 解密数据
     * @throws CryptoException
     */
    public static byte[] decryptTripleDES(byte[] kap, byte[] kbp, byte[] src) throws CryptoException {
        if (kap == null || kap.length != 8 || kbp == null || kbp.length != 8 || src == null || src.length % 8 != 0) {
            throw new CryptoException("密钥长度错误");
        }
        byte[] keyBytes = ByteUtil.contactArray(kap, kbp);
        keyBytes = ByteUtil.contactArray(keyBytes, kap);
        return decryptTripleDES(keyBytes, src, "ECB", "NoPadding");
    }

    public static byte[] decryptTripleDES(byte[] keyBytes, byte[] src, String mode, String padding)
            throws CryptoException {
        String transformation = "DESede" + "/" + mode + "/" + padding;
        return decryptMode(keyBytes, src, transformation);
    }

    /**
     * @param keyBytes
     *            加密密钥
     * @param src
     *            未加密数据
     * @return 加密数据
     * @throws CryptoException
     */
    public static byte[] encryptDES(byte[] keyBytes, byte[] src) throws CryptoException {
        // if (keyBytes == null || keyBytes.length != 8) {
        // throw new CryptoException("密钥长度错误");
        // }
        src = olsysDesPadding(src);
        return encryptMode(keyBytes, src, "DES/ECB/NoPadding");
    }

    /**
     * @param keyBytes
     *            解密密钥
     * @param src
     *            加密数据
     * @return 解密数据
     * @throws CryptoException
     */
    public static byte[] decryptDES(byte[] keyBytes, byte[] src) throws CryptoException {
        if (keyBytes == null || keyBytes.length != 8 || src == null || src.length % 8 != 0) {
            throw new CryptoException("密钥长度错误");
        }
        return decryptMode(keyBytes, src, "DES/ECB/NoPadding");
    }

    private static String getAlgorithm(String transformation) {
        int index = transformation.indexOf("/");
        if (index == -1) {
            return transformation;
        } else {
            return transformation.substring(0, index);
        }
    }

    private static byte[] olsysDesPadding(byte[] src) {
        int mod = src.length % 8;
        if (mod != 0) {
            for (int i = 0; i < 8 - mod; i++) {
                src = ByteUtil.append(src, (byte) 0x00);
            }
        }
        return src;
    }

    public static byte[] olsysMacPadding(byte[] src) {
        int mod = src.length % 8;
        if (mod != 0) {
            src = ByteUtil.append(src, (byte) 0x80);
            mod = src.length % 8;
            if (mod != 0)
                for (int i = 0; i < 8 - mod; i++) {
                    src = ByteUtil.append(src, (byte) 0x00);
                }
        } else {
            src = ByteUtil.contactArray(src, ByteUtil.hexStringToBytes("8000000000000000"));
        }
        return src;
    }

    public static byte[] encryptDESwithCBC(byte[] keyBytes, byte[] src) throws CryptoException {
        if (keyBytes == null || keyBytes.length != 8) {
            throw new CryptoException("密钥长度错误");
        }
        src = olsysMacPadding(src);
        int count = src.length / 8;
        byte[] output = ByteUtil.hexStringToBytes("0000000000000000");
        for (int i = 0; i < count; i++) {
            int current = 8 * i;
            byte[] block = ByteUtil.subArray(src, current, current + 8);
            byte[] toEncrypt = ByteUtil.arrayXOR(output, block);
            output = encryptMode(keyBytes, toEncrypt, "DES/ECB/NoPadding");
        }
        return output;
    }

    public static String enTDEA(String skap, String skbp, String ssrc) {
        try {
            byte[] kap = skap.getBytes();
            byte[] kbp = skbp.getBytes();
            byte[] src = ssrc.getBytes("UTF-8");
            byte[] en1 = encryptDES(kap, src);
            byte[] de2 = decryptDES(kbp, en1);
            byte[] en3 = encryptDES(kap, de2);
            String str = ByteUtil.toHexString(en3);
            return str;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String deTDEA(String skap, String skbp, String secret) {
        try {
            byte[] kap = skap.getBytes();
            byte[] kbp = skbp.getBytes();
            byte[] b_secret = ByteUtil.hexStringToBytes(secret);
            byte[] de1 = decryptDES(kap, b_secret);
            byte[] en2 = encryptDES(kbp, de1);
            byte[] de3 = decryptDES(kap, en2);
            byte x = 00;
            String ssrc = new String(ByteUtil.stripEnd(de3, x), "UTF-8");
            return ssrc;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public static byte[] disperse(byte[] leftKeybyte, byte[] rightKey, byte[] factor) throws CryptoException {
        byte[] left = encryptTripleDES(leftKeybyte, rightKey, factor);
        byte[] right = encryptTripleDES(leftKeybyte, rightKey, ByteUtil.bitComplement(factor));
        return ByteUtil.contactArray(left, right);
    }

    public static byte[] createMd5MessageDigest(byte[] input) throws CryptoException {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(input);
            return md.digest();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CryptoException(e.getMessage());
        }
    }

    public static boolean verifyMd5MessageDigest(byte[] input, byte[] origDigest) throws CryptoException {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(input);
            return MessageDigest.isEqual(md.digest(), origDigest);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CryptoException(e.getMessage());
        }
    }

    /**
     * 加密数据（AES算法CBC模式零补码）
     * 
     * @param content
     *            需要加密的内容
     * @param key
     *            加密密码
     * @param iv
     *            加密向量
     * @return 加密后的字节数据
     * @author wu
     */
    public static byte[] encryptByAES(byte[] content, byte[] key, byte[] iv) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
            // "算法/模式/补码方式"
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            int blockSize = cipher.getBlockSize();

            int plaintextLength = content.length;
            if (plaintextLength % blockSize != 0) {
                plaintextLength = plaintextLength + (blockSize - (plaintextLength % blockSize));
            }

            byte[] plaintext = new byte[plaintextLength];
            System.arraycopy(content, 0, plaintext, 0, content.length);

            // 使用CBC模式，需要一个向量iv，可增加加密算法的强度
            IvParameterSpec ivps = new IvParameterSpec(iv);
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivps);

            return cipher.doFinal(plaintext);
        } catch (Exception ex) {
            log.error(ex.getMessage());
            ex.printStackTrace();
        }

        return null;
    }

    /**
     * 解密数据（AES算法CBC模式零补码）
     * 
     * @param content
     *            需要解密的内容
     * @param key
     *            解密密码
     * @param iv
     *            解密向量
     * @return 解密后的字节数据
     * @author wu
     */
    public static byte[] decryptByAES(byte[] content, byte[] key, byte[] iv) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
            // "算法/模式/补码方式"
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            // 使用CBC模式，需要一个向量iv，可增加加密算法的强度
            IvParameterSpec ivps = new IvParameterSpec(iv);
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivps);

            return cipher.doFinal(content);
        } catch (Exception ex) {
            log.error(ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * 加密数据（AES算法CBC模式零补码）
     * 
     * @param content
     *            需要加密的内容
     * @param key
     *            加密密码
     * @param md5Key
     *            是否对key进行md5加密
     * @param iv
     *            加密向量
     * @return 加密后的内容
     * @author wu
     */
    public static String encryptByAES(String content, String key, String iv) {
        String result = null;

        try {
            byte[] byteContent = content.getBytes(CryptoUtil.DEFAULT_CHARSET);
            byte[] byteKey = key.getBytes(CryptoUtil.DEFAULT_CHARSET);
            byte[] byteIv = iv.getBytes(CryptoUtil.DEFAULT_CHARSET);

            byte[] byteResult = CryptoUtil.encryptByAES(byteContent, byteKey, byteIv);

            if (null != byteResult) {
                result = new String(byteResult, CryptoUtil.DEFAULT_CHARSET);
            }
        } catch (Exception ex) {
            log.error(ex.getMessage());
        }

        return result;
    }

    /**
     * 解密数据（AES算法CBC模式零补码）
     * 
     * @param content
     *            需要解密的内容
     * @param key
     *            解密密码
     * @param iv
     *            解密向量
     * @return 解密后的内容
     * @author wu
     */
    public static String decryptByAES(String content, String key, String iv) {
        String result = null;

        try {
            byte[] byteContent = content.getBytes(CryptoUtil.DEFAULT_CHARSET);
            byte[] byteKey = key.getBytes(CryptoUtil.DEFAULT_CHARSET);
            byte[] byteIv = iv.getBytes(CryptoUtil.DEFAULT_CHARSET);

            byte[] byteResult = CryptoUtil.decryptByAES(byteContent, byteKey, byteIv);

            if (null != byteResult) {
                result = new String(byteResult, CryptoUtil.DEFAULT_CHARSET);
            }
        } catch (Exception ex) {
            log.error(ex.getMessage());
        }
        return result;
    }

    public static void main(String[] args) {
        try {
            String skap = "feinno01";
            String skbp = "xinmeicq";
            String key = "50a9ea50333c8bf6";
            String content = "测试加密内容";
            // String sen =
            // enTDEA(skap,skbp,"2b72a54c199dfa2396b449b2f63630ad|cqkf_ganliling|农信通积分超市采购台帐");
            // System.out.println(sen);
            // System.out.println(deTDEA(skap,skbp,"E88C2FA6F407418A29DCF17151401C6A4190A40CA41829FEEE3CD9879E4BF5438713F0B3A58663B1F6F2F0AAFA1E9E8D"));

            // String skap = "ke.zhang";
            // String skbp = "kirk0000";
            // String sen = enTDEA(skap,skbp,"农信通积分超市采购台帐");
            // System.out.println(sen);
            // System.out.println(deTDEA(skap, skbp,
            // "C512CB414BF2DE93DBB55A311788EE3E"));
            String temp = encryptByAES(content, key, key);
            System.out.println(temp);
            String content2 = decryptByAES(temp, key, key);
            System.out.println(content2);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}